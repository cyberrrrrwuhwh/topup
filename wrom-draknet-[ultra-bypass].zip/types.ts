
export type UserRole = 'user' | 'reseller' | 'admin' | 'developer';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  files?: { name: string; type: string; size: number; content?: string }[];
  sources?: any[];
  responseTime?: number; // Latency in ms
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  updatedAt: number;
}

export interface UserUsage {
  count: number;
  lastReset: string; 
}

export interface RoleInfo {
  role: UserRole;
  expiryDate: number | null;
  code: string | null;
}

export interface UserIdentity {
  name: string | null;
}
