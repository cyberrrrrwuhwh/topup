
import React, { useState, useRef, useEffect } from 'react';
import { Send, Trash2, Cpu, Sparkles, Settings, X, Clock, User, ExternalLink, Paperclip, MessageSquare, Shield, LayoutDashboard, Plus, History, Menu, Terminal, Search, Zap, Code, Star, Crown, ShieldAlert, Calendar, LogOut } from 'lucide-react';
import { sendMessageStream } from '../services/aiService';
import { Message, UserUsage, RoleInfo, UserIdentity, Conversation, UserRole } from '../types';
import ChatMessage from './ChatMessage';

const FREE_LIMIT = 40;
const MASTER_KEY_DEV = "301010";

const App: React.FC = () => {
  const [identity, setIdentity] = useState<UserIdentity>({ name: null });
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<string | null>(null);
  
  const [inputValue, setInputValue] = useState('');
  const [status, setStatus] = useState<'idle' | 'thinking' | 'typing'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showSidebar, setShowSidebar] = useState(window.innerWidth > 1280);
  const [roleAnim, setRoleAnim] = useState<UserRole | null>(null);
  const [genDays, setGenDays] = useState(30);
  
  const [roleInfo, setRoleInfo] = useState<RoleInfo>({ role: 'user', expiryDate: null, code: null });
  const [usage, setUsage] = useState<UserUsage>({ count: 0, lastReset: new Date().toDateString() });
  const [currentlyTypingText, setCurrentlyTypingText] = useState('');
  const [tempName, setTempName] = useState('');
  const [pendingFiles, setPendingFiles] = useState<{ name: string; type: string; size: number; content?: string }[]>([]);
  const [currentSources, setCurrentSources] = useState<any[]>([]);

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [avgResponseTime, setAvgResponseTime] = useState(0);

  const isVIP = roleInfo.role !== 'user' || roleInfo.code === 'VIP';

  useEffect(() => {
    const savedName = localStorage.getItem('drakent_name');
    const savedConvs = localStorage.getItem('drakent_conversations');
    const savedActiveId = localStorage.getItem('drakent_active_id');
    const savedUsage = localStorage.getItem('drakent_global_usage');
    const savedRole = localStorage.getItem('drakent_role');

    if (savedName) setIdentity({ name: savedName });
    if (savedConvs) {
      const parsedConvs = JSON.parse(savedConvs);
      setConversations(parsedConvs);
      if (savedActiveId && parsedConvs.find((c: any) => c.id === savedActiveId)) {
        setActiveConvId(savedActiveId);
      } else if (parsedConvs.length > 0) {
        setActiveConvId(parsedConvs[0].id);
      }
    }
    if (savedRole) setRoleInfo(JSON.parse(savedRole));
    
    if (savedUsage) {
      const parsed = JSON.parse(savedUsage);
      const today = new Date().toDateString();
      if (parsed.lastReset !== today) {
        const newUsage = { count: 0, lastReset: today };
        setUsage(newUsage);
        localStorage.setItem('drakent_global_usage', JSON.stringify(newUsage));
      } else {
        setUsage(parsed);
      }
    } else {
      const initialUsage = { count: 0, lastReset: new Date().toDateString() };
      setUsage(initialUsage);
      localStorage.setItem('drakent_global_usage', JSON.stringify(initialUsage));
    }
  }, []);

  useEffect(() => {
    if (identity.name) localStorage.setItem('drakent_name', identity.name);
    localStorage.setItem('drakent_conversations', JSON.stringify(conversations));
    localStorage.setItem('drakent_active_id', activeConvId || '');
    localStorage.setItem('drakent_role', JSON.stringify(roleInfo));
    localStorage.setItem('drakent_global_usage', JSON.stringify(usage));
  }, [identity, conversations, activeConvId, roleInfo, usage]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [conversations, activeConvId, currentlyTypingText, status]);

  const triggerRoleAnim = (role: UserRole) => {
    setRoleAnim(role);
    setTimeout(() => setRoleAnim(null), 3000);
  };

  const handleLogout = () => {
    if (window.confirm("Apakah Anda yakin ingin keluar dari sistem Draknet?")) {
      localStorage.removeItem('drakent_name');
      localStorage.removeItem('drakent_conversations');
      localStorage.removeItem('drakent_active_id');
      localStorage.removeItem('drakent_role');
      window.location.reload();
    }
  };

  const handleRoleVerify = (code: string) => {
    if (code === MASTER_KEY_DEV) {
      setRoleInfo({ role: 'developer', expiryDate: null, code: 'MASTER' });
      triggerRoleAnim('developer');
      return true;
    }

    if (code.startsWith("201030")) {
      const roleDigit = code.slice(-2);
      let role: UserRole = 'user';
      let label: string = 'VIP';
      
      if (roleDigit === '10') { role = 'user'; label = 'VIP'; }
      else if (roleDigit === '20') { role = 'reseller'; label = 'RESELLER'; }
      else if (roleDigit === '30') { role = 'admin'; label = 'ADMIN'; }
      else return false;

      const endTimeStr = code.slice(-6, -2); 
      const endDateStr = code.slice(-12, -6); 
      
      const day = parseInt(endDateStr.slice(0, 2));
      const month = parseInt(endDateStr.slice(2, 4)) - 1;
      const year = 2000 + parseInt(endDateStr.slice(4, 6));
      const hour = parseInt(endTimeStr.slice(0, 2));
      const minute = parseInt(endTimeStr.slice(2, 4));
      
      const expiry = new Date(year, month, day, hour, minute).getTime();
      
      if (expiry < Date.now()) {
        setError("Protocol Expired.");
        return false;
      }

      setRoleInfo({ role, expiryDate: expiry, code: label });
      triggerRoleAnim(role);
      return true;
    }
    return false;
  };

  const generateCode = (type: 'VIP' | 'RESL' | 'ADMN') => {
    const prefix = "201030";
    const now = new Date();
    const end = new Date();
    end.setDate(now.getDate() + genDays);

    const fmtDate = (d: Date) => d.getDate().toString().padStart(2, '0') + (d.getMonth()+1).toString().padStart(2, '0') + d.getFullYear().toString().slice(-2);
    const fmtTime = (d: Date) => d.getHours().toString().padStart(2, '0') + d.getMinutes().toString().padStart(2, '0');

    const roleDigit = type === 'VIP' ? '10' : type === 'RESL' ? '20' : '30';
    const code = `${prefix}${genDays.toString().padStart(2, '0')}${fmtDate(now)}${fmtTime(now)}${fmtDate(end)}${fmtTime(end)}${roleDigit}`;
    
    alert(`GENERATED ${type} PROTOCOL: ${code}`);
    navigator.clipboard.writeText(code);
  };

  const executeDevCommand = async (cmd: string) => {
    if (roleInfo.role !== 'developer') return false;
    const timestamp = Date.now();
    let content = "";
    if (cmd === '/cekserver') content = `**DRAKNET CORE STATUS**\n- API: STABLE\n- Model: Gemini 3 Pro\n- Local: SYNCED\n- Security: ACTIVE`;
    else if (cmd === '/ping') content = `**LATENCY: ${Math.floor(Math.random() * 30) + 10}ms**`;
    
    if (content) {
      const aiMsg: Message = { id: Date.now().toString(), role: 'assistant', content, timestamp: Date.now() };
      updateConversationMessages([...currentMessages, { id: 'cmd', role: 'user', content: cmd, timestamp }, aiMsg]);
      return true;
    }
    return false;
  };

  const updateConversationMessages = (newMessages: Message[]) => {
    if (!activeConvId) {
      const newId = Date.now().toString();
      setConversations([{ id: newId, title: newMessages[0]?.content.substring(0, 20) || 'Draknet Archive', messages: newMessages, updatedAt: Date.now() }, ...conversations]);
      setActiveConvId(newId);
    } else {
      setConversations(conversations.map(c => c.id === activeConvId ? { ...c, messages: newMessages, updatedAt: Date.now() } : c));
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (ev) => setPendingFiles(prev => [...prev, { name: file.name, type: file.type, size: file.size, content: ev.target?.result as string }]);
      reader.readAsText(file);
    });
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!inputValue.trim() && pendingFiles.length === 0) || status !== 'idle') return;
    
    if (inputValue.startsWith('/') && await executeDevCommand(inputValue.trim())) { setInputValue(''); return; }

    if (roleInfo.role === 'user' && !isVIP && usage.count >= FREE_LIMIT) {
      setError("Limit harian (40 chat) tercapai. Silakan upgrade ke VIP.");
      return;
    }

    const userMessage: Message = { id: Date.now().toString(), role: 'user', content: inputValue.trim() || `Attachment Payload`, timestamp: Date.now(), files: [...pendingFiles] };
    const updatedMsgs = [...currentMessages, userMessage];
    updateConversationMessages(updatedMsgs);
    setInputValue(''); setPendingFiles([]); setStatus('thinking');

    const startTime = Date.now();
    try {
      const finalPrompt = userMessage.files?.length ? `${userMessage.content}\n\n[FILE ATTACHMENTS]\n${userMessage.files.map(f => `FILE: ${f.name}\n${f.content}`).join('\n')}` : userMessage.content;
      let lastText = "";
      
      await sendMessageStream(
        updatedMsgs.map((m, i) => ({ role: m.role, content: i === updatedMsgs.length - 1 ? finalPrompt : m.content })), 
        identity.name || 'User', 
        roleInfo.code || roleInfo.role,
        (text) => { setStatus('typing'); lastText = text; setCurrentlyTypingText(text); }, 
        (sources) => setCurrentSources(sources)
      );

      const latency = Date.now() - startTime;
      const aiMessage: Message = { id: Date.now().toString(), role: 'assistant', content: lastText, timestamp: Date.now(), sources: currentSources, responseTime: latency };
      setAvgResponseTime(prev => prev === 0 ? latency : Math.floor((prev + latency) / 2));
      updateConversationMessages([...updatedMsgs, aiMessage]);
      setCurrentlyTypingText(''); setStatus('idle');
      
      const newUsage = { ...usage, count: usage.count + 1 };
      setUsage(newUsage);
      localStorage.setItem('drakent_global_usage', JSON.stringify(newUsage));

    } catch (err: any) { setError(err.message); setStatus('idle'); }
  };

  const activeConversationObj = conversations.find(c => c.id === activeConvId);
  const currentMessages = activeConversationObj?.messages || [];

  const deleteConversation = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const filtered = conversations.filter(c => c.id !== id);
    setConversations(filtered);
    if (activeConvId === id) setActiveConvId(filtered.length > 0 ? filtered[0].id : null);
  };

  if (!identity.name) {
    return (
      <div className="h-screen bg-[#020617] flex items-center justify-center p-6">
        <div className="w-full max-sm:px-4 space-y-6">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 bg-indigo-600 rounded-xl mx-auto flex items-center justify-center border border-indigo-400/30 shadow-xl animate-bounce"><Cpu className="w-6 h-6 text-white" /></div>
            <h1 className="text-xl font-black text-white tracking-widest uppercase">WROM DRAKNET</h1>
          </div>
          <div className="bg-[#0b0c10] border border-white/5 p-8 rounded-3xl space-y-6 shadow-2xl">
            <input type="text" value={tempName} onChange={e => setTempName(e.target.value)} placeholder="Operator alias..." className="w-full bg-slate-900 border border-white/10 rounded-xl p-3 text-white text-center font-bold outline-none" />
            <button onClick={() => tempName.trim() && setIdentity({ name: tempName.trim() })} className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-black rounded-xl uppercase text-xs tracking-widest transition-all">Initialize</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-[#020617] text-slate-200 font-sans overflow-hidden">
      <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-[#05060a] border-r border-white/5 transition-transform lg:relative lg:translate-x-0 ${showSidebar ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-white/5 flex items-center justify-between">
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Archives</span>
            <button onClick={() => setShowSidebar(false)} className="lg:hidden text-slate-500"><X className="w-4 h-4" /></button>
          </div>
          <div className="p-3"><button onClick={() => {setActiveConvId(null); setShowSidebar(false);}} className="w-full p-2.5 bg-indigo-600/5 border border-indigo-500/10 rounded-lg text-[9px] font-black uppercase text-indigo-400 hover:bg-indigo-600/10 flex items-center gap-2"><Plus className="w-3.5 h-3.5" />New Workspace</button></div>
          <div className="flex-1 overflow-y-auto custom-scrollbar px-3 space-y-1">
            {conversations.map(c => (
              <div key={c.id} onClick={() => setActiveConvId(c.id)} className={`group flex items-center justify-between p-2.5 rounded-lg cursor-pointer transition-all duration-300 ${activeConvId === c.id ? 'bg-slate-900 border border-indigo-500/20 text-white' : 'text-slate-500 hover:bg-white/5'}`}>
                <div className="flex items-center gap-2 overflow-hidden">
                  <MessageSquare className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="text-[10px] font-bold truncate uppercase">{c.title}</span>
                </div>
                <button onClick={(e) => { e.stopPropagation(); deleteConversation(c.id, e); }} className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-500 transition-opacity"><Trash2 className="w-3 h-3" /></button>
              </div>
            ))}
          </div>
          <div className="p-4 bg-slate-950/50 border-t border-white/5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-black">{identity.name?.[0].toUpperCase()}</div>
              <div className="flex flex-col overflow-hidden">
                <span className="text-[10px] font-black uppercase text-slate-200 truncate">{identity.name}</span>
                <div className="flex items-center gap-1.5">
                  <span className={`px-1.5 py-0.5 rounded text-[7px] font-black uppercase tracking-tighter ${
                    roleInfo.role === 'developer' ? 'bg-indigo-500 text-white' :
                    roleInfo.role === 'admin' ? 'bg-yellow-500 text-black' :
                    roleInfo.role === 'reseller' ? 'bg-emerald-500 text-black' :
                    isVIP ? 'bg-white text-black' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {roleInfo.code || roleInfo.role}
                  </span>
                </div>
              </div>
            </div>
            <button onClick={handleLogout} className="w-full p-2 bg-red-500/10 border border-red-500/20 rounded-lg text-[8px] font-black uppercase text-red-500 hover:bg-red-500/20 flex items-center justify-center gap-2 transition-all">
              <LogOut className="w-3 h-3" /> Logout Operator
            </button>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 bg-[#020617]">
        <header className="px-6 py-3 border-b border-white/5 bg-[#020617]/80 backdrop-blur-md flex items-center justify-between z-20">
          <div className="flex items-center gap-4">
            <button onClick={() => setShowSidebar(true)} className={`p-1.5 text-slate-500 transition-colors ${showSidebar ? 'hidden' : 'block'}`}><Menu className="w-4 h-4" /></button>
            <div className="flex items-center gap-3">
              <h1 className="text-[10px] font-black tracking-[0.4em] uppercase text-white">WROM DRAKNET BETA</h1>
              <span className={`px-2 py-0.5 rounded text-[7px] font-black uppercase tracking-widest shadow-lg ${
                roleInfo.role === 'developer' ? 'bg-indigo-600 text-white shadow-indigo-500/20' :
                roleInfo.role === 'admin' ? 'bg-yellow-500 text-black shadow-yellow-500/20' :
                roleInfo.role === 'reseller' ? 'bg-emerald-500 text-black shadow-emerald-500/20' :
                isVIP ? 'bg-white text-black shadow-white/20' : 'bg-slate-800 text-slate-400'
              }`}>
                {roleInfo.code || roleInfo.role}
              </span>
            </div>
          </div>
          <button onClick={() => setShowSettings(true)} className="p-2 bg-slate-900/50 rounded-lg border border-white/5 text-slate-600 hover:text-white transition-all"><Settings className="w-4 h-4" /></button>
        </header>

        <main ref={scrollRef} className="flex-1 overflow-y-auto custom-scrollbar p-4 md:p-8 space-y-6">
          <div className="max-w-3xl mx-auto space-y-8">
            {currentMessages.length === 0 && (
              <div className="py-20 text-center space-y-4 opacity-50 animate-pulse">
                <Sparkles className="w-8 h-8 mx-auto text-indigo-500" />
                <div className="space-y-1">
                  <h2 className="text-sm font-black uppercase tracking-[0.5em] text-white">Architectural Link</h2>
                  <p className="text-[7px] font-black tracking-[0.3em]">SYSTEMS ONLINE // INITIALIZE REQUEST</p>
                </div>
              </div>
            )}
            {currentMessages.map(m => (
              <ChatMessage 
                key={m.id} 
                message={m} 
                userRole={roleInfo.code || roleInfo.role} 
              />
            ))}
            {status !== 'idle' && (
              <div className="flex gap-4 animate-in fade-in duration-500">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center shadow-lg"><Sparkles className="w-5 h-5 text-white animate-pulse" /></div>
                <div className="bg-white rounded-2xl px-5 py-4 shadow-xl max-w-[85%] border-b-4 border-slate-200">
                   {status === 'thinking' ? (
                     <div className="flex items-center gap-2">
                       <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-bounce"></div>
                       <span className="text-[9px] font-black uppercase tracking-widest text-indigo-600">Processing...</span>
                     </div>
                   ) : (
                     <ChatMessage 
                        message={{ id: 't', role: 'assistant', content: currentlyTypingText, timestamp: Date.now() }} 
                        isTypingOnly 
                        userRole={roleInfo.code || roleInfo.role}
                     />
                   )}
                </div>
              </div>
            )}
          </div>
        </main>

        <footer className="p-4 md:p-8 border-t border-white/5 bg-[#020617]/50 backdrop-blur-md">
          <div className="max-w-3xl mx-auto relative">
            {error && <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center justify-between text-[9px] font-black text-red-400 uppercase transition-all">{error}<button onClick={() => setError(null)}><X className="w-3 h-3" /></button></div>}
            <form onSubmit={handleSendMessage} className="relative">
              <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" multiple />
              <button type="button" onClick={() => fileInputRef.current?.click()} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-700 hover:text-indigo-400 transition-colors"><Paperclip className="w-4 h-4" /></button>
              <input type="text" value={inputValue} onChange={e => setInputValue(e.target.value)} placeholder="Inject command or request code..." disabled={status !== 'idle'} className="w-full bg-[#05060a] border border-white/5 rounded-xl py-4 pl-12 pr-12 text-slate-200 text-xs font-bold outline-none focus:border-indigo-500/20 shadow-xl transition-all" />
              <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-500 active:scale-90 transition-all"><Send className="w-4 h-4" /></button>
            </form>
            {roleInfo.role === 'user' && !isVIP && (
              <div className="mt-3 flex justify-center">
                <div className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[8px] font-black uppercase tracking-widest text-slate-500">
                  Daily Limit: {usage.count} / {FREE_LIMIT} Chat
                </div>
              </div>
            )}
          </div>
        </footer>

        {showSettings && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-3xl animate-in fade-in duration-500">
            <div className="bg-[#0b0c10] border border-white/5 rounded-[2.5rem] w-full max-w-sm shadow-2xl overflow-hidden">
              <div className="p-6 border-b border-white/5 flex justify-between items-center"><h2 className="text-[10px] font-black uppercase tracking-[0.3em]">Access Panel</h2><button onClick={() => setShowSettings(false)} className="hover:rotate-90 transition-transform duration-300"><X className="w-5 h-5 text-slate-600" /></button></div>
              <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto custom-scrollbar">
                <div className="space-y-2">
                  <label className="text-[8px] font-black uppercase text-slate-500 ml-1">Injection Protocol Key</label>
                  <input type="password" placeholder="••••••••" onKeyDown={e => e.key === 'Enter' && handleRoleVerify(e.currentTarget.value) && (e.currentTarget.value = '')} className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-indigo-400 font-mono text-xs outline-none focus:border-indigo-500/40 transition-colors" />
                </div>
                {roleInfo.role !== 'user' && (
                  <div className="space-y-4 pt-4 border-t border-white/5">
                    <p className="text-[8px] font-black uppercase text-indigo-500 tracking-widest">Protocol Generator</p>
                    <div className="flex items-center gap-3 bg-white/5 p-3 rounded-xl border border-white/5">
                      <Calendar className="w-3 h-3 text-slate-500" />
                      <input type="number" value={genDays} onChange={e => setGenDays(Math.max(1, parseInt(e.target.value) || 1))} className="bg-transparent text-[10px] font-black text-white outline-none w-12" />
                      <span className="text-[8px] font-black uppercase text-slate-600">Days</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button onClick={() => generateCode('VIP')} className="p-3 bg-white border border-slate-200 rounded-xl text-[9px] font-black uppercase text-black hover:bg-slate-100 flex items-center justify-center gap-2 transition-all"><Star className="w-3.5 h-3.5" />VIP</button>
                      {(roleInfo.role === 'admin' || roleInfo.role === 'developer') && (
                        <button onClick={() => generateCode('RESL')} className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-[9px] font-black uppercase text-emerald-500 hover:bg-emerald-500/20 flex items-center justify-center gap-2 transition-all"><Zap className="w-3.5 h-3.5" />Reseller</button>
                      )}
                      {roleInfo.role === 'developer' && (
                        <button onClick={() => generateCode('ADMN')} className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-xl text-[9px] font-black uppercase text-yellow-500 hover:bg-yellow-500/20 flex items-center justify-center gap-2 transition-all col-span-2"><ShieldAlert className="w-3.5 h-3.5" />Admin Access</button>
                      )}
                    </div>
                  </div>
                )}
                <div className="space-y-2 pt-4 border-t border-white/5">
                  <a href="https://t.me/halilintardev" target="_blank" className="flex items-center justify-between p-3.5 bg-slate-900 border border-white/5 rounded-xl text-[10px] font-black hover:bg-indigo-500/10 transition-all">Chat Developer <MessageSquare className="w-4 h-4 text-indigo-500" /></a>
                  <a href="https://t.me/chhalilintar" target="_blank" className="flex items-center justify-between p-3.5 bg-slate-900 border border-white/5 rounded-xl text-[10px] font-black hover:bg-indigo-500/10 transition-all">CH Developer <Shield className="w-4 h-4 text-indigo-500" /></a>
                </div>
              </div>
            </div>
          </div>
        )}

        {roleAnim && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-2xl overflow-hidden animate-in fade-in duration-700">
            <div className="relative z-10 text-center space-y-6 animate-in zoom-in duration-700 ease-out">
              <div className={`w-32 h-32 mx-auto rounded-[2.5rem] flex items-center justify-center shadow-[0_0_50px_rgba(79,70,229,0.5)] border-2 ${
                roleAnim === 'developer' ? 'bg-indigo-600 border-indigo-400' : 
                roleAnim === 'admin' ? 'bg-yellow-600 border-yellow-400' : 
                roleAnim === 'reseller' ? 'bg-emerald-600 border-emerald-400' : 
                'bg-white border-slate-200'
              }`}>
                {roleAnim === 'developer' ? <ShieldAlert className="w-16 h-16 text-white" /> : 
                 roleAnim === 'admin' ? <Crown className="w-16 h-16 text-white" /> : 
                 roleAnim === 'reseller' ? <Zap className="w-16 h-16 text-white" /> : 
                 <Star className="w-16 h-black" />}
              </div>
              <div className="space-y-2">
                <h2 className="text-4xl font-black uppercase text-white tracking-[0.5em] animate-pulse">ACCESS GRANTED</h2>
                <p className="text-[12px] font-black tracking-[0.8em] uppercase text-indigo-400">{roleAnim} protocol active</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default App;
