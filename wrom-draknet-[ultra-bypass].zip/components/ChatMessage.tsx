
import React, { useState, useEffect } from 'react';
import { User, Sparkles, ChevronDown, ChevronUp, Copy, Play, Check, X, FileCode, Paperclip, ExternalLink, Globe, Download, Maximize2 } from 'lucide-react';
import { Message } from '../types';

interface ChatMessageProps {
  message: Message;
  isTypingOnly?: boolean;
  userRole?: string | null;
}

const CodeBlock: React.FC<{ file: { language: string, code: string }; onPreview: (code: string) => void; isDone?: boolean }> = ({ file, onPreview, isDone }) => {
  const [isOpen, setIsOpen] = useState(true);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (isDone && file.code.split('\n').length > 15) {
      setIsOpen(false);
    }
  }, [isDone]);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(file.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    const blob = new Blob([file.code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `draknet_source_${Date.now()}.${file.language || 'txt'}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const isWeb = ['html', 'css', 'javascript', 'js'].includes(file.language.toLowerCase());

  return (
    <>
      <div className={`my-4 rounded-xl overflow-hidden border border-slate-200 bg-[#0a0a0a] shadow-lg w-full transition-all duration-500 ease-in-out ${isOpen ? 'max-h-[1200px]' : 'max-h-12'}`}>
        <div 
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center justify-between px-4 py-3 bg-slate-50 border-b border-slate-200 cursor-pointer hover:bg-slate-100 transition-colors"
        >
          <div className="flex items-center gap-3">
            <FileCode className="w-4 h-4 text-indigo-600" />
            <span className="text-[10px] font-black text-slate-800 uppercase tracking-widest">{file.language || 'Sequence'}</span>
            {!isOpen && <span className="text-[9px] text-slate-500 truncate max-w-[150px] font-mono">{file.code.substring(0, 40)}...</span>}
          </div>
          <div className="flex items-center gap-1.5" onClick={e => e.stopPropagation()}>
            <button onClick={() => setIsFullScreen(true)} title="View Full" className="p-1.5 hover:bg-white rounded-lg text-slate-500 hover:text-indigo-600 transition-all">
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
            <button onClick={handleDownload} title="Download" className="p-1.5 hover:bg-white rounded-lg text-slate-500 hover:text-indigo-600 transition-all">
              <Download className="w-3.5 h-3.5" />
            </button>
            <button onClick={handleCopy} title="Copy" className="p-1.5 hover:bg-white rounded-lg text-slate-500 hover:text-indigo-600 transition-all">
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
            {isWeb && (
              <button onClick={() => onPreview(file.code)} title="Preview" className="p-1.5 hover:bg-indigo-600 hover:text-white rounded-lg text-indigo-600 transition-all border border-indigo-100">
                <Play className="w-3.5 h-3.5 fill-current" />
              </button>
            )}
            <div className={`ml-2 text-slate-400 transition-transform duration-300 ${isOpen ? 'rotate-0' : 'rotate-180'}`}><ChevronUp className="w-4 h-4" /></div>
          </div>
        </div>
        <div className={`transition-opacity duration-500 ${isOpen ? 'opacity-100' : 'opacity-0'}`}>
          {isOpen && (
            <div className="p-6 overflow-x-auto custom-scrollbar max-h-[600px] bg-slate-950">
              <pre className="text-[12px] font-mono text-indigo-100/90 leading-relaxed selection:bg-indigo-500/30"><code>{file.code}</code></pre>
            </div>
          )}
        </div>
      </div>

      {isFullScreen && (
        <div className="fixed inset-0 z-[110] bg-black/98 backdrop-blur-3xl p-4 md:p-10 flex flex-col animate-in zoom-in duration-500 ease-out">
          <div className="flex items-center justify-between mb-6 border-b border-white/10 pb-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-xl"><FileCode className="w-6 h-6 text-indigo-600" /></div>
              <div>
                <h3 className="text-white font-black uppercase text-sm tracking-widest">Architectural Full-View</h3>
                <p className="text-[9px] text-slate-500 uppercase tracking-widest">{file.language} Sequence - {file.code.split('\n').length} lines</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
               <button onClick={handleDownload} className="px-5 py-2.5 bg-white text-black rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 transition-all flex items-center gap-2">
                 <Download className="w-4 h-4" /> Download
               </button>
               <button onClick={handleCopy} className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-500 transition-all flex items-center gap-2">
                 {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />} {copied ? 'Copied' : 'Copy'}
               </button>
               <button onClick={() => setIsFullScreen(false)} className="p-3 bg-red-500 text-white rounded-xl transition-all hover:rotate-90">
                 <X className="w-6 h-6" />
               </button>
            </div>
          </div>
          <div className="flex-1 overflow-auto custom-scrollbar bg-black p-8 rounded-3xl border border-white/5 shadow-inner">
            <pre className="text-[14px] font-mono text-indigo-100/90 leading-relaxed"><code>{file.code}</code></pre>
          </div>
        </div>
      )}
    </>
  );
};

const ChatMessage: React.FC<ChatMessageProps> = ({ message, isTypingOnly = false, userRole }) => {
  const isUser = message.role === 'user';
  const [previewCode, setPreviewCode] = useState<string | null>(null);

  const renderTextSegment = (text: string, key: string) => {
    if (!text.trim()) return null;
    return (
      <div key={key} className="w-full space-y-3">
        {text.split('\n').map((line, i) => {
          if (!line.trim()) return <div key={i} className="h-3" />;
          let content = line
            .replace(/\*\*(.*?)\*\*/g, `<strong class="${isUser ? 'text-white' : 'text-indigo-950'} font-bold">$1</strong>`)
            .replace(/`(.*?)`/g, `<code class="${isUser ? 'bg-white/20 text-white' : 'bg-slate-100 text-indigo-700'} px-1.5 py-0.5 rounded font-mono text-[11px]">$1</code>`)
            .replace(/^- (.*$)/gm, `<li class="ml-4 flex items-start gap-2 ${isUser ? 'text-white/90' : 'text-slate-700'} mb-1.5"><span class="mt-2 w-1.5 h-1.5 ${isUser ? 'bg-white' : 'bg-indigo-600'} rounded-full flex-shrink-0"></span><span>$1</span></li>`);

          return <p key={i} className={`leading-relaxed text-[15px] break-words font-medium ${isUser ? 'text-white' : 'text-slate-900'}`} dangerouslySetInnerHTML={{ __html: content }} />;
        })}
      </div>
    );
  };

  const formatContent = () => {
    const text = message.content;
    const segments: React.ReactNode[] = [];
    const codeBlockRegex = /```(\w+)?\s*([\s\S]*?)```/g;
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        segments.push(renderTextSegment(text.substring(lastIndex, match.index), `text-${lastIndex}`));
      }
      segments.push(<CodeBlock key={`code-${match.index}`} isDone={!isTypingOnly} file={{ language: match[1] || 'Sequence', code: match[2].trim() }} onPreview={setPreviewCode} />);
      lastIndex = codeBlockRegex.lastIndex;
    }
    if (lastIndex < text.length) {
      segments.push(renderTextSegment(text.substring(lastIndex), `text-${lastIndex}`));
    }

    return (
      <div className="w-full">
        {segments}
        {message.sources && message.sources.length > 0 && (
          <div className={`mt-6 pt-4 border-t ${isUser ? 'border-white/20' : 'border-slate-100'} space-y-2`}>
            <div className="flex items-center gap-2 px-1">
              <Globe className={`w-3.5 h-3.5 ${isUser ? 'text-white' : 'text-indigo-600'}`} />
              <span className={`text-[9px] font-black uppercase tracking-widest ${isUser ? 'text-white/70' : 'text-slate-500'}`}>Grounding Matrix</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {message.sources.map((chunk, i) => chunk.web && (
                <a key={i} href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className={`flex items-center gap-2 px-3 py-2 rounded-xl transition-all group ${
                  isUser ? 'bg-white/10 hover:bg-white/20 border border-white/10' : 'bg-slate-50 hover:bg-slate-100 border border-slate-200'
                }`}>
                  <ExternalLink className={`w-3 h-3 ${isUser ? 'text-white' : 'text-slate-400 group-hover:text-indigo-600'}`} />
                  <span className={`text-[10px] font-bold truncate max-w-[140px] ${isUser ? 'text-white' : 'text-slate-600'}`}>{chunk.web.title || 'Source'}</span>
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  if (isTypingOnly) return <div className="w-full">{formatContent()}</div>;

  return (
    <div className={`flex gap-4 animate-in fade-in slide-in-from-bottom-3 duration-700 w-full ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
      <div className={`w-11 h-11 rounded-[1.2rem] flex items-center justify-center flex-shrink-0 border-2 transition-all duration-500 ${
        isUser ? 'bg-slate-900 border-indigo-500/20 text-white' : 'bg-indigo-600 border-white text-white shadow-[0_10px_30px_rgba(79,70,229,0.4)]'
      }`}>
        {isUser ? <User className="w-6 h-6" /> : <Sparkles className="w-6 h-6 animate-pulse" />}
      </div>
      <div className={`flex flex-col max-w-[calc(100%-70px)] ${isUser ? 'items-end' : 'items-start'}`}>
        <div className={`px-6 py-5 rounded-[2rem] shadow-2xl border transition-all duration-500 w-full overflow-hidden ${
          isUser ? 'bg-indigo-600 border-indigo-500 text-white rounded-tr-none' : 'bg-white border-slate-200 text-slate-900 rounded-tl-none ring-1 ring-slate-100'
        }`}>
          {formatContent()}
        </div>
        <div className="flex items-center gap-3 mt-2.5 px-3 text-[9px] font-black uppercase tracking-widest text-slate-500/80">
          <div className="flex items-center gap-2">
            <span className={isUser ? 'text-slate-500' : 'text-indigo-600 tracking-[0.2em]'}>{isUser ? 'OPERATOR' : 'WROM DRAKNET'}</span>
            {!isUser && userRole && (
              <span className={`px-1.5 py-0.5 rounded text-[7px] font-black uppercase tracking-normal ${
                userRole.includes('VIP') ? 'bg-white text-black border border-slate-200 shadow-sm' : 'bg-indigo-600 text-white'
              }`}>
                {userRole}
              </span>
            )}
          </div>
          {message.responseTime && <span className="opacity-40">L-SYNC: {message.responseTime}MS</span>}
        </div>
      </div>

      {previewCode && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-6 bg-black/98 backdrop-blur-3xl animate-in fade-in duration-500">
          <div className="relative w-full max-w-6xl h-[90vh] bg-white rounded-[2.5rem] overflow-hidden flex flex-col border border-indigo-100 shadow-[0_0_80px_rgba(79,70,229,0.3)]">
            <div className="px-6 py-5 bg-slate-50 flex items-center justify-between border-b border-slate-200">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center"><Play className="w-5 h-5 text-white fill-current" /></div>
                <span className="text-[11px] font-black text-slate-900 uppercase tracking-[0.4em]">Draknet Sequence Sandbox</span>
              </div>
              <button onClick={() => setPreviewCode(null)} className="p-2.5 hover:bg-red-50 hover:text-red-600 rounded-full text-slate-400 transition-all hover:rotate-90"><X className="w-6 h-6" /></button>
            </div>
            <iframe title="Draknet Sandbox" srcDoc={previewCode} className="w-full h-full border-none bg-white" sandbox="allow-scripts" />
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatMessage;
