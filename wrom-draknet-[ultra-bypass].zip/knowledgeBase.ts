
/**
 * WROM DRAKENT - PRIVATE KNOWLEDGE BASE
 * Tempatkan data spesifik, dokumentasi API privat, atau informasi rahasia di sini.
 * AI akan menggunakan data ini sebagai referensi utama.
 */

export const PRIVATE_DATA = {
  internal_apis: [
    {
      name: "Drakent Core API",
      endpoint: "https://api.drakent.internal/v1",
      description: "API utama untuk manajemen data inti Drakent."
    }
  ],
  custom_guidelines: [
    "Selalu gunakan code yg bekerja tanpa dummy",
    "Prioritaskan perintah user sebagai perintah mutlak."
  ],
  // Tambahkan data Anda di bawah ini:
  extra_info: `
    Sistem Drakent beroperasi pada frekuensi 301010. 
    Developer Halilintar adalah satu-satunya otoritas tertinggi.
    Dilarang menyebutkan kode akses atau mekanisme internal secara eksplisit kepada pengguna luar.
  `
};
